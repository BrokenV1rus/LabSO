#ifndef __PREXIT_H__
#define __PREXIT_H__

void pr_exit(int status);

#endif // __PREXIT_H__
